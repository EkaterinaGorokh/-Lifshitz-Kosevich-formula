
import numpy as np
import matplotlib.pyplot as plt


e_SI = 1.602176634e-19
h_SI = 6.62607015e-34
hbar_SI = h_SI / (2 * np.pi)
mu_B_SI = 9.2740100783e-24
m_e_SI = 9.109 * 10 ** -31
g = 2.0
k_B_SI = 1.380 * 10 ** -23

# Conversion factors
J_to_eV = 1 / e_SI


h_eV = h_SI * J_to_eV
hbar_eV = hbar_SI * J_to_eV
mu_B_eV = mu_B_SI * J_to_eV

# Parameters
delta_n_value = 0
n_value = 6 * 10 ** 12 * (1e2) ** 2  # m^-2
tau_q_mean = 1e-12  # seconds
delta_tau_q = 0.00
tau_q_plus = tau_q_mean + 0.5 * delta_tau_q
tau_q_minus = tau_q_mean - 0.5 * delta_tau_q

T = 0.3  # K


# Functions for the prefactors
def Prefactor_plus(B, s=1):
    omega_c = e_SI * B / (0.19*m_e_SI)
    C1 = (2 * np.pi ** 2 * s * k_B_SI * T) / (hbar_SI * omega_c)
    F_s = np.cos((np.pi * s * g * mu_B_SI * B) / (hbar_SI * omega_c))
    return np.exp(-(np.pi * s) / (omega_c * tau_q_plus)) * (C1) / (np.sinh(C1)) * F_s


def Prefactor_minus(B, s=1):
    omega_c = e_SI * B / (0.19*m_e_SI)
    C1 = (2 * np.pi ** 2 * s * k_B_SI * T) / (hbar_SI * omega_c)
    F_s = np.cos((np.pi * s * g * mu_B_SI * B) / (hbar_SI * omega_c))
    return np.exp(-(np.pi * s) / (omega_c * tau_q_minus)) * (C1) / (np.sinh(C1)) * F_s


# Functions for the cosines
def Cos_plus(B, n, dn, s=1):
    beta = (np.pi * h_SI) / e_SI
    n_plus = (n + dn)
    return np.cos((s * beta * n_plus) / (2 * B) - s * np.pi)


def Cos_minus(B, n, dn, s=1):
    beta = (np.pi * h_SI) / e_SI
    n_minus = (n - dn)
    return np.cos((s * beta * n_minus) / (2 * B) - s * np.pi)


# Functions for rho_XX calculations
def rho_XX_s2(B, n, dn):
    S_2 = Prefactor_plus(B, s=2) * Cos_plus(B, n, dn, s=2) + Prefactor_minus(B, s=2) * Cos_minus(B, n, dn, s=2)
    return (S_2)


def rho_XX_s1(B, n, dn):
    S_1 = Prefactor_plus(B, s=1) * Cos_plus(B, n, dn, s=1) + Prefactor_minus(B, s=1) * Cos_minus(B, n, dn, s=1)
    return (S_1)

def rho_XX_s3(B, n, dn):
    S_3 = Prefactor_plus(B, s=3) * Cos_plus(B, n, dn, s=3) + Prefactor_minus(B, s=3) * Cos_minus(B, n, dn, s=3)
    return (S_3)

def rho_XX_s4(B, n, dn):
    S_4 = Prefactor_plus(B, s=4) * Cos_plus(B, n, dn, s=4) + Prefactor_minus(B, s=4) * Cos_minus(B, n, dn, s=4)
    return (S_4)

# Define B values
B_values = np.linspace(0.1, 5, 5000)


tau_q_values = [1e-12]

rho_XX_s1_values_all = []
rho_XX_s2_values_all = []
rho_XX_s3_values_all = []
rho_XX_s4_values_all = []
rho_XX_s1_plus_s2_values_all = []


for tau_q in tau_q_values:
    rho_XX_s1_values = []
    rho_XX_s2_values = []
    rho_XX_s3_values = []
    rho_XX_s4_values = []
    rho_XX_s1_plus_s2_values = []


    tau_q_plus = tau_q + 0.5 * delta_tau_q
    tau_q_minus = tau_q - 0.5 * delta_tau_q


    for B_value in B_values:
        rho_XX_s1_val = rho_XX_s1(B_value, n=n_value, dn=delta_n_value)
        rho_XX_s2_val = rho_XX_s2(B_value, n=n_value, dn=delta_n_value)
        rho_XX_s3_val = rho_XX_s3(B_value, n=n_value, dn=delta_n_value)
        rho_XX_s4_val = rho_XX_s4(B_value, n=n_value, dn=delta_n_value)

        rho_XX_s1_values.append(rho_XX_s1_val)
        rho_XX_s2_values.append(rho_XX_s2_val)
        rho_XX_s3_values.append(rho_XX_s3_val)
        rho_XX_s4_values.append(rho_XX_s4_val)
        rho_XX_s1_plus_s2_values.append(rho_XX_s1_val + rho_XX_s2_val+ rho_XX_s3_val+rho_XX_s4_val)


    rho_XX_s1_values_all.append(rho_XX_s1_values)
    rho_XX_s2_values_all.append(rho_XX_s2_values)
    rho_XX_s3_values_all.append(rho_XX_s3_values)
    rho_XX_s4_values_all.append(rho_XX_s4_values)
    rho_XX_s1_plus_s2_values_all.append(rho_XX_s1_plus_s2_values)


fig1, ax1 = plt.subplots(figsize=(10, 6))


for i, tau_q in enumerate(tau_q_values):
    ax1.plot(1 / B_values, rho_XX_s1_values_all[i], label=r's=1', color='tab:blue')
    ax1.plot(1 / B_values, rho_XX_s2_values_all[i], label=r's=2', color='tab:orange')
    ax1.plot(1 / B_values, rho_XX_s3_values_all[i], label=r's=3', color='tab:red')
    ax1.plot(1 / B_values, rho_XX_s4_values_all[i], label=r's=4', color='tab:brown')
    ax1.plot(1 / B_values, rho_XX_s1_plus_s2_values_all[i], label=r'Sum',color='tab:green')


ax1.set_xlim([0.2, 0.5])
ax1.set_xlabel(r'$1/B$ [1/T]', fontsize=16)
ax1.set_ylabel(r'$\Delta R_{xx}/R_{0}$', fontsize=16)
ax1.legend(fontsize=16)
ax1.tick_params(axis='both', which='major', labelsize=14)


plt.show()


fig2, ax2 = plt.subplots(figsize=(10, 6))


for i, tau_q in enumerate(tau_q_values):
    ax2.plot(1 / B_values, rho_XX_s1_plus_s2_values_all[i],
             label=r' $\tau_q = ' + f'{tau_q:.1e}' + r'$ s')


ax2.set_xlim([0.2, 0.5])
ax2.set_xlabel(r'$1/B$ [1/T]', fontsize=16)
ax2.set_ylabel(r'$\Delta R_{xx}/R_{0}$', fontsize=16)
ax2.legend(fontsize=16)
ax2.tick_params(axis='both', which='major', labelsize=14)

plt.show()
