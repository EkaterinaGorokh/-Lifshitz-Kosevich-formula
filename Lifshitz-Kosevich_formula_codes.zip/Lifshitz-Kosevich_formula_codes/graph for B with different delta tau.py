
import numpy as np
import matplotlib.pyplot as plt


e_SI = 1.602176634e-19
h_SI = 6.62607015e-34
hbar_SI = h_SI / (2 * np.pi)
mu_B_SI = 9.2740100783e-24
m_e_SI = 9.109e-31
g = 2.0
k_B_SI = 1.380e-23


J_to_eV = 1 / e_SI
h_eV = h_SI * J_to_eV
hbar_eV = hbar_SI * J_to_eV
mu_B_eV = mu_B_SI * J_to_eV

# Parameters
delta_n_value = 1e14
n_value = 6e16  # m^-2
tau_q_mean = 3e-12  # seconds
T = 0.3  # K


delta_tau_q_values = [0, 0.1e-11]


def Prefactor_plus(B, tau_q_plus, s=1):
    omega_c = e_SI * B / (0.19 * m_e_SI)
    C1 = (2 * np.pi ** 2 * s * k_B_SI * T) / (hbar_SI * omega_c)
    F_s = np.cos((np.pi * s * g * mu_B_SI * B) / (hbar_SI * omega_c))
    return np.exp(-(np.pi * s) / (omega_c * tau_q_plus)) * (C1 / np.sinh(C1)) * F_s

def Prefactor_minus(B, tau_q_minus, s=1):
    omega_c = e_SI * B / (0.19 * m_e_SI)
    C1 = (2 * np.pi ** 2 * s * k_B_SI * T) / (hbar_SI * omega_c)
    F_s = np.cos((np.pi * s * g * mu_B_SI * B) / (hbar_SI * omega_c))
    return np.exp(-(np.pi * s) / (omega_c * tau_q_minus)) * (C1 / np.sinh(C1)) * F_s


def Cos_plus(B, n, dn, s=1):
    beta = (np.pi * h_SI) / e_SI
    return np.cos((s * beta * (n + dn)) / (2 * B) - s * np.pi)

def Cos_minus(B, n, dn, s=1):
    beta = (np.pi * h_SI) / e_SI
    return np.cos((s * beta * (n - dn)) / (2 * B) - s * np.pi)


def rho_XX_s(B, n, dn, tau_q_plus, tau_q_minus, s):
    return (
        Prefactor_plus(B, tau_q_plus, s=s) * Cos_plus(B, n, dn, s=s)
        + Prefactor_minus(B, tau_q_minus, s=s) * Cos_minus(B, n, dn, s=s)
    )


B_values = np.linspace(0.1, 5, 5000)

# Store results for each delta_tau_q
rho_XX_s1_all, rho_XX_s2_all, rho_XX_s1_plus_s2_all = [], [], []

for delta_tau_q in delta_tau_q_values:
    tau_q_plus = tau_q_mean + 0.5 * delta_tau_q
    tau_q_minus = tau_q_mean - 0.5 * delta_tau_q

    rho_s1 = []
    rho_s2 = []
    combined = []

    for B in B_values:
        val_s1 = rho_XX_s(B, n_value, delta_n_value, tau_q_plus, tau_q_minus, s=1)
        val_s2 = rho_XX_s(B, n_value, delta_n_value, tau_q_plus, tau_q_minus, s=2)

        rho_s1.append(val_s1)
        rho_s2.append(val_s2)
        combined.append(val_s1 + val_s2)

    rho_XX_s1_all.append(rho_s1)
    rho_XX_s2_all.append(rho_s2)
    rho_XX_s1_plus_s2_all.append(combined)



fig1, ax1 = plt.subplots(figsize=(10, 6))
for i, delta_tau_q in enumerate(delta_tau_q_values):
        ax1.plot(1 / B_values, rho_XX_s1_all[i], label=fr'$\rho_{{xx, s=1}}, \Delta \tau_q = {delta_tau_q:.1e}$ s')
        ax1.plot(1 / B_values, rho_XX_s2_all[i], label=fr'$\rho_{{xx, s=2}}, \Delta \tau_q = {delta_tau_q:.1e}$ s')

ax1.set_xlim([0.2, 0.5])
ax1.set_xlabel(r'$1/B$ [1/T]', fontsize=16)
ax1.set_ylabel(r'$\Delta R_{xx}/R_{0}$', fontsize=16)


ax1.legend(fontsize=16)
ax1.tick_params(axis='both', which='major', labelsize=14)



plt.show()

fig2, ax2 = plt.subplots(figsize=(10, 6))
for i, delta_tau_q in enumerate(delta_tau_q_values):
    ax2.plot(1 / B_values, rho_XX_s1_plus_s2_all[i],
             label=fr'$\Delta \tau_q = {delta_tau_q:.1e}$ s')
ax2.set_xlim([0.2, 0.5])

ax2.set_xlabel(r'$1/B$ [1/T]', fontsize=16)
ax2.set_ylabel(r'$\Delta R_{xx}/R_{0}$', fontsize=16)

ax2.legend(loc='upper right', fontsize=16)
ax2.tick_params(axis='both', which='major', labelsize=14)

plt.show()