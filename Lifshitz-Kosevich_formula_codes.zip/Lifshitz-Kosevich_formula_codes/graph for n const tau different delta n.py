
import numpy as np
import matplotlib.pyplot as plt


e_SI = 1.602176634e-19
h_SI = 6.62607015e-34
hbar_SI = h_SI / (2 * np.pi)
mu_B_SI = 9.2740100783e-24
m_e_SI = 9.109 * 10 ** -31
g = 2.0
k_B_SI = 1.380 * 10 ** -23


h_eV = h_SI / e_SI
hbar_eV = hbar_SI / e_SI
mu_B_eV = mu_B_SI / e_SI


T = 0.3  # Kelvin
B_fixed = 5  # Tesla


n_cm2_values = np.linspace(3e12, 9e12, 5000)  # in cm^-2
n_values = n_cm2_values * 1e4  # convert to m^-2


def get_tau_q(n):
    n0 = 1e16
    return 3e-12 * (n0 / n)


def Prefactor(B, tau_q, s=1):
    omega_c = e_SI * B / (0.19 * m_e_SI)
    C1 = (2 * np.pi**2 * s * k_B_SI * T) / (hbar_SI * omega_c)
    F_s = np.cos((np.pi * s * g * mu_B_SI * B) / (hbar_SI * omega_c))
    return np.exp(-(np.pi * s) / (omega_c * tau_q)) * C1 / np.sinh(C1) * F_s


def Cos(B, n, dn, s=1, sign=1):
    beta = (np.pi * h_SI) / e_SI
    n_shifted = n + sign * dn
    return np.cos((s * beta * n_shifted) / (2 * B) - s * np.pi)


def rho_XX_total(B, n, dn):
    tau_q = get_tau_q(n)
    total = 0
    for s in range(1, 2):
        pref = Prefactor(B, tau_q, s=s)
        total += pref * (Cos(B, n, dn, s=s, sign=1) + Cos(B, n, dn, s=s, sign=-1))
    return total

delta_n_values = [0, 2e14, 3e15]
colors = ['tab:blue', 'tab:orange', 'tab:green']
labels = [r'$\Delta n = 0.0\ e+00$ cm$^{-2}$', r'$\Delta n = 2.0\ e+10$ cm$^{-2}$', r'$\Delta n = 3.0\ e+11$ cm$^{-2}$']

plt.figure(figsize=(10, 6))

for delta_n_value, color, label in zip(delta_n_values, colors, labels):
    rho_XX_list = []
    for n_val in n_values:
        rho_XX_list.append(rho_XX_total(B_fixed, n_val, delta_n_value))
    plt.plot(n_cm2_values, rho_XX_list, label=label, color=color, linewidth=2)


plt.xlabel(r'$n$ [$\mathrm{cm}^{-2}$]', fontsize=16)
plt.ylabel(r'$\Delta R_{xx}/R_{0}$', fontsize=16)
plt.legend(fontsize=16)
plt.tick_params(axis='both', which='major', labelsize=14)
ax = plt.gca()  # Get current axes
ax.xaxis.get_offset_text().set_fontsize(14)
plt.tight_layout()
plt.show()
