import numpy as np
import matplotlib.pyplot as plt

e_SI = 1.602176634e-19
h_SI = 6.62607015e-34
hbar_SI = h_SI / (2 * np.pi)
mu_B_SI = 9.2740100783e-24  
m_e_SI = 9.109 * 10 ** -31
g = 2.0
k_B_SI = 1.380 * 10 ** -23

# Parameters
delta_n_value = 0
n_value = 6 * 10 ** 12 * (1e2) ** 2  # m^-2
tau_q_fixed = 3e-12  # Fixed tau_q
delta_tau_q = 0.00  # No asymmetry


T_values = [0.3, 1.0, 4.2]  # K


B_values = np.linspace(0.1, 5, 5000)


def Prefactor(B, tau_q, T, s=1):
    omega_c = e_SI * B / (0.19 * m_e_SI)
    C1 = (2 * np.pi ** 2 * s * k_B_SI * T) / (hbar_SI * omega_c)
    F_s = np.cos((np.pi * s * g * mu_B_SI * B) / (hbar_SI * omega_c))
    return np.exp(-(np.pi * s) / (omega_c * tau_q)) * (C1) / (np.sinh(C1)) * F_s


def Cos_plus(B, n, dn, s=1):
    beta = (np.pi * h_SI) / e_SI
    n_plus = (n + dn)
    return np.cos((s * beta * n_plus) / (2 * B) - s * np.pi)

def Cos_minus(B, n, dn, s=1):
    beta = (np.pi * h_SI) / e_SI
    n_minus = (n - dn)
    return np.cos((s * beta * n_minus) / (2 * B) - s * np.pi)


def rho_XX_s(B, n, dn, tau_q, T, s):
    S = Prefactor(B, tau_q, T, s=s) * Cos_plus(B, n, dn, s=s) + Prefactor(B, tau_q, T, s=s) * Cos_minus(B, n, dn, s=s)
    return S


rho_XX_s1_all = []
rho_XX_s2_all = []
rho_XX_total_all = []


for T in T_values:
    rho_XX_s1 = []
    rho_XX_s2 = []
    rho_XX_total = []

    for B in B_values:
        s1 = rho_XX_s(B, n=n_value, dn=delta_n_value, tau_q=tau_q_fixed, T=T, s=1)
        s2 = rho_XX_s(B, n=n_value, dn=delta_n_value, tau_q=tau_q_fixed, T=T, s=2)
        rho_XX_s1.append(s1)
        rho_XX_s2.append(s2)
        rho_XX_total.append(s1 + s2)

    rho_XX_s1_all.append(rho_XX_s1)
    rho_XX_s2_all.append(rho_XX_s2)
    rho_XX_total_all.append(rho_XX_total)


fig1, ax1 = plt.subplots(figsize=(10, 6))

for i, T in enumerate(T_values):
    ax1.plot(1 / B_values, rho_XX_s1_all[i], label=fr'$s=1, T = {T} \, \mathrm{{K}}$')

    ax1.plot(1 / B_values, rho_XX_s2_all[i], label=fr'$s=2, T = {T} \, \mathrm{{K}}$')

ax1.set_xlim([0.2, 0.5])
ax1.set_xlabel(r'$1/B$ [1/T]', fontsize=16)
ax1.set_ylabel(r'$\Delta R_{xx}/R_{0}$', fontsize=16)

ax1.legend(fontsize=16)
ax1.tick_params(axis='both', which='major', labelsize=14)



plt.show()



fig2, ax2 = plt.subplots(figsize=(10, 6))

for i, T in enumerate(T_values):
    ax2.plot(1 / B_values, rho_XX_total_all[i], label=fr'$T = {T} \, \mathrm{{K}}$')

ax2.set_xlim([0.2, 0.5])
ax2.set_xlabel(r'$1/B$ [1/T]', fontsize=16)
ax2.set_ylabel(r'$\Delta R_{xx}/R_{0}$', fontsize=16)
ax2.set_title(r'$s=1 + s=2$, $n = 6\cdot10^{12} \, \mathrm{cm}^{-2}, \Delta n = 0, \tau_q = 3\cdot 10^{-12} \, \mathrm{s}$')
ax2.legend(fontsize=16)
ax2.tick_params(axis='both', which='major', labelsize=14)
plt.show()