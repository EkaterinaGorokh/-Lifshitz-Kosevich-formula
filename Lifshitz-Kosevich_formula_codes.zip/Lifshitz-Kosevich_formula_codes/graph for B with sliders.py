import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider
from scipy.constants import e, h, k, pi


hbar = h / (2 * pi)
m_e = 9.109e-31
mu_B = 9.2740100783e-24
g = 2


B = np.linspace(0.5, 5, 500)
inv_B = 1 / B


def Prefactor(B, s, tau, T):
    omega_c = e * B / (0.19 * m_e)
    C1 = (2 * pi**2 * s * k * T) / (hbar * omega_c)
    F_s = np.cos((pi * s * g * mu_B * B) / (hbar * omega_c))
    return ((np.exp(-(pi * s) / (omega_c * tau))) * C1 / np.sinh(C1)) * F_s

def Cos(B, n_val, s):
    beta = pi * h / e
    return np.cos((s * beta * n_val) / B - s * pi)

def compute_sum_of_harmonics(B, tau, delta_tau, delta_n, s_max, n_carrier, power, amplitude, T):
    tau_plus = tau + delta_tau / 2
    tau_minus = tau - delta_tau / 2
    n1 = (n_carrier + delta_n) / 2
    n2 = (n_carrier - delta_n) / 2
    result = np.zeros_like(B)
    for s in range(1, int(s_max) + 1):
        harmonic = (
            Prefactor(B, s, tau_plus, T) * Cos(B, n1, s) +
            Prefactor(B, s, tau_minus, T) * Cos(B, n2, s)
        )
        result += harmonic
    return amplitude * (B ** power) * result

def compute_background(B, a, b):
    return a * B**2 + b


fig, ax = plt.subplots(figsize=(10, 6))
plt.subplots_adjust(bottom=0.7)


init_params = {
    'tau': 1.28e-12,
    'delta_tau': 0.5e-12,
    'delta_n': 1e14,
    's_max': 3,
    'n_carrier': 6e12 * 1e4,
    'power': 2,
    'amplitude': 0.0226,
    'a': 0.00359,
    'b': -0.0025,
    'T': 0.3
}


harmonics = compute_sum_of_harmonics(B, init_params['tau'], init_params['delta_tau'],
                                      init_params['delta_n'], init_params['s_max'],
                                      init_params['n_carrier'], init_params['power'],
                                      init_params['amplitude'], init_params['T'])
background = compute_background(B, init_params['a'], init_params['b'])

line_fit, = ax.plot(inv_B, harmonics - background, label="Theoretical Curve", color="tab:red")

ax.set_xlabel("1 / B [1/T]")
ax.set_ylabel(r"$(R_{xx} - R_{B=0}) / R_{B=0}$")
ax.legend()
ax.grid(True)


slider_axes = {
    'smax': plt.axes([0.15, 0.60, 0.7, 0.03]),
    'tau': plt.axes([0.15, 0.55, 0.7, 0.03]),
    'dtau': plt.axes([0.15, 0.50, 0.7, 0.03]),
    'n': plt.axes([0.15, 0.45, 0.7, 0.03]),
    'dn': plt.axes([0.15, 0.40, 0.7, 0.03]),
    'power': plt.axes([0.15, 0.35, 0.7, 0.03]),
    'amplitude': plt.axes([0.15, 0.30, 0.7, 0.03]),
    'a': plt.axes([0.15, 0.25, 0.7, 0.03]),
    'b': plt.axes([0.15, 0.20, 0.7, 0.03]),
    'T': plt.axes([0.15, 0.15, 0.7, 0.03])
}

sliders = {
    'tau': Slider(slider_axes['tau'], 'τ mean (s)', 0.5e-12, 5e-12, valinit=init_params['tau']),
    'dtau': Slider(slider_axes['dtau'], '$\Delta τ$ (s)', -1e-12, 1e-12, valinit=init_params['delta_tau']),
    'dn': Slider(slider_axes['dn'], '$\Delta n (m^{-2})$', 1e13, 5e15, valinit=init_params['delta_n']),
    'power': Slider(slider_axes['power'], 'B power', 0, 2.0, valinit=init_params['power']),
    'amplitude': Slider(slider_axes['amplitude'], 'A (amplitude)', 0.01, 2, valinit=init_params['amplitude']),
    'smax': Slider(slider_axes['smax'], 'Max Harmonic (s)', 1, 10, valinit=init_params['s_max'], valstep=1),
    'n': Slider(slider_axes['n'], 'n ($m^{-2}$)', 5e16, 7e16, valinit=init_params['n_carrier']),
    'a': Slider(slider_axes['a'], 'a (background)', -0.01, 0.01, valinit=init_params['a']),
    'b': Slider(slider_axes['b'], 'b (offset)', -0.05, 0.05, valinit=init_params['b']),
    'T': Slider(slider_axes['T'], 'T (K)', 0.3, 4.0, valinit=init_params['T'])
}


def update(val):
    tau = sliders['tau'].val
    delta_tau = sliders['dtau'].val
    delta_n = sliders['dn'].val
    power = sliders['power'].val
    amplitude = sliders['amplitude'].val
    s_max = sliders['smax'].val
    n_carrier = sliders['n'].val
    a = sliders['a'].val
    b = sliders['b'].val
    T = sliders['T'].val

    harmonics = compute_sum_of_harmonics(B, tau, delta_tau, delta_n, s_max, n_carrier, power, amplitude, T)
    background = compute_background(B, a, b)
    line_fit.set_ydata(harmonics - background)
    fig.canvas.draw_idle()


for slider in sliders.values():
    slider.on_changed(update)

ax.set_xlim(0.2, 0.5)


plt.show()
